package com.kb.db;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.kb.model.Address;
import com.kb.model.Applicant;
import com.kb.util.HibernateUtil;

public class Main {
	public static void main(String[] args) {
		// Get session factory using Hibernate Util class
		SessionFactory sf = HibernateUtil.getSessionFactory();
		// Get session from Sesson factory
		Session session = sf.openSession();

		// Begin transaction
		Transaction t = session.beginTransaction();
		
		//Create Applicant Model data
		Applicant applicant = new Applicant();
		applicant.setFirstName("John");
		applicant.setLastName("KC");
		applicant.setAge(28);
		applicant.setEducation("Graduation");

		//Create Passport Model data
		Address currentAdd = new Address();
		currentAdd.setStreet("Royal road");
		currentAdd.setCity("Newyork");
		currentAdd.setZipcode("10001");
		
		//Associate Applicant to  current Address
		currentAdd.setApplicant(applicant);
		
		Address permanentAdd = new Address();
		permanentAdd.setStreet("Manyar Road");
		permanentAdd.setCity("Sydney");
		permanentAdd.setZipcode("2060");
		
		//Associate Applicant to permanent Address
		permanentAdd.setApplicant(applicant);
		
		session.persist(applicant);
		session.persist(currentAdd);
		session.persist(permanentAdd);

		// Commit the transaction and close the session
		t.commit();
		session.close();
		System.out.println("successfully persisted Applicant details");
	}

}
